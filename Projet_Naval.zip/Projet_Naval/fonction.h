typedef enum {
    WATER,
    WATER_SHOT,
    BOAT,
    WRECK,
} CaseType;

typedef struct Boat {
    
    int size;
    int x, y;
    char orientation; // 0 pour horizontal, 1 pour vertical
} Boat;

typedef struct Board{

    CaseType **Matrice;
    int size;
} Board;

typedef struct Game {
    Board *playerBoard;
    Board *computerBoard;
    Boat *playerBoats;
    Boat *computerBoats;
} Game;

#define MAX_BOAT 5
#define BOARD_SIZE 10


Board* createBoard(int size);
Boat* createBoat(int size, int x, int y, char orientation);
Game createGame();
void DisplayBoard (Board Board);





void freeGame(Game game);