#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include"fonction.h"









int main (int argc, char *argv[]) {

    Boat firstBoat = createBoat(5, 3, 3, 'H');

    return 0;

}


