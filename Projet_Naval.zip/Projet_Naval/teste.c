// Implémentation de la fonction d'initialisation
Game createGame() {
    Game game;

    // Initialiser les plateaux de jeu
    game.playerBoard = createBoard(BOARD_SIZE);
    game.computerBoard = createBoard(BOARD_SIZE);

    // Allouer de la mémoire pour les tableaux de bateaux
    game.playerBoat = malloc(MAX_BOAT * sizeof(Boat));
    game.computerBoat = malloc(MAX_BOAT * sizeof(Boat));

    // Ici, vous devez ajouter la logique pour positionner les bateaux sur les plateaux.
    // Par exemple, vous pourriez utiliser createBoat et une fonction supplémentaire pour placer chaque bateau.

    return game;
}

// N'oubliez pas de libérer la mémoire à la fin du jeu.
void freeGame(Game game) {
    for (int i = 0; i < game.playerBoard.size; i++) {
        free(game.playerBoard.Matrice[i]);
    }
    free(game.playerBoard.Matrice);

    for (int i = 0; i < game.computerBoard.size; i++) {
        free(game.computerBoard.Matrice[i]);
    }
    free(game.computerBoard.Matrice);

    free(game.playerBoat);
    free(game.computerBoat);
}





   /*/ if (newBoat == NULL) {
        fprintf(stderr, "Memory allocation failed for Boat structure.\n");
        exit(EXIT_FAILURE); // Exit the program in case of a memory allocation failure
    }*/








void DisplayBoard (Board Board) {

    for (int i = 0; i < Board.size; i++) {
        for (int j = 0; j < Board.size; i++)
        {
            /* code */
        }
        
    }
    
}



/*
    Game game;

    game.playerBoard = createBoard(BOARD_SIZE);
    game.computerBoard = createBoard(BOARD_SIZE);
    game.playerBoat = createBoat(MAX_BOAT, 0, 0, 0);
    game.computerBoat = createBoat(MAX_BOAT, 0, 0, 0);

    if (game.playerBoard == NULL || game.computerBoard == NULL ||
        game.playerBoat == NULL || game.computerBoat == NULL) {
        // Gestion d'erreur en cas d'allocation mémoire échouée
    }

    // Assurez-vous que les bateaux ne se chevauchent pas (implémentez cette logique)
    if (isOverlap(game.playerBoard, game.playerBoat) || isOverlap(game.computerBoard, game.computerBoat)) {
        // Gestion d'erreur en cas de chevauchement de bateaux
    }

    return game;
}


*/



Game createGame() {
    Game game;

    // Création des plateaux de jeu
    game.playerBoard = malloc(sizeof(Board));
    game.computerBoard = malloc(sizeof(Board));

    // Vérification de l'allocation de mémoire
    if (game.playerBoard == NULL || game.computerBoard == NULL) {
        fprintf(stderr, "Memory allocation failed for game boards.\n");
        exit(EXIT_FAILURE);
    }

    // Initialisation des plateaux de jeu avec une taille prédéfinie (BOARD_SIZE)
    *game.playerBoard = createBoard(BOARD_SIZE);
    *game.computerBoard = createBoard(BOARD_SIZE);

    // Allocation de mémoire pour les tableaux de bateaux des joueurs
    game.playerBoat = malloc(MAX_BOAT * sizeof(Boat));
    game.computerBoat = malloc(MAX_BOAT * sizeof(Boat));

    // Vérification de l'allocation de mémoire
    if (game.playerBoat == NULL || game.computerBoat == NULL) {
        fprintf(stderr, "Memory allocation failed for player and computer boats.\n");
        exit(EXIT_FAILURE);
    }

    // Vous devrez ajouter le code pour initialiser les bateaux ici
    // Par exemple, en utilisant la fonction createBoat pour chaque bateau
    
    return game;
}


void freeGame(Game game) {
    // Libérer la mémoire allouée pour les plateaux
    for (int i = 0; i < game.playerBoard->size; i++) {
        free(game.playerBoard->Matrice[i]);
    }
    free(game.playerBoard->Matrice);
    free(game.playerBoard);

    for (int i = 0; i < game.computerBoard->size; i++) {
        free(game.computerBoard->Matrice[i]);
    }
    free(game.computerBoard->Matrice);
    free(game.computerBoard);

    // Libérer la mémoire allouée pour les tableaux de bateaux
    free(game.playerBoat);
    free(game.computerBoat);
}
#include <stdlib.h>
#include <time.h> // For random number generation

// Function to randomly place boats on a board
void placeBoatsOnBoard(Board *board, Boat *boats, int numBoats) {
    // Randomly place each boat
    for (int i = 0; i < numBoats; i++) {
        int placed = 0;
        while (!placed) {
            // Generate random position and orientation
            int x = rand() % board->size;
            int y = rand() % board->size;
            char orientation = rand() % 2; // 0 for horizontal, 1 for vertical

            // Check if the boat can be placed (not implemented here)
            // If it can be placed, update the board and set placed to 1
            // Otherwise, try again
        }
    }
}





void freeBoard(Board *board) {
    if (board != NULL) {
        for (int i = 0; i < board->size; i++) {
            free(board->Matrice[i]);
        }
        free(board->Matrice);
    }
}



void placeBoatsOnBoard(Board *board, Boat *boats, int numBoats) {
    // Randomly place each boat
    for (int i = 0; i < numBoats; i++) {
        int placed = 0;
        while (!placed) {
            // Generate random position and orientation
            int x = rand() % board->size;
            int y = rand() % board->size;
            char orientation = rand() % 2; // 0 for horizontal, 1 for vertical

            // Check if the boat can be placed (not implemented here)
            // If it can be placed, update the board and set placed to 1
            // Otherwise, try again
        }
    }
}

Game createGame() {
    Game newGame;

    // Seed the random number generator
    srand(time(NULL));

    // Create boards for the player and the computer
    newGame.playerBoard = malloc(sizeof(Board));
    *newGame.playerBoard = createBoard(BOARD_SIZE);
    newGame.computerBoard = malloc(sizeof(Board));
    *newGame.computerBoard = createBoard(BOARD_SIZE);

    // Allocate memory for the boats
    newGame.playerBoat = malloc(MAX_BOAT * sizeof(Boat));
    newGame.computerBoat = malloc(MAX_BOAT * sizeof(Boat));

    // Place boats on the boards
    placeBoatsOnBoard(newGame.playerBoard, newGame.playerBoat, MAX_BOAT);
    placeBoatsOnBoard(newGame.computerBoard, newGame.computerBoat, MAX_BOAT);

    return newGame;
}


typedef struct Game {
    Board *playerBoard;
    Board *computerBoard;
    Boat playerBoats[MAX_BOAT]; // Tableau de bateaux pour le joueur
    Boat computerBoats[MAX_BOAT]; // Tableau de bateaux pour l'ordinateur
} Game;




// Fonction pour afficher un plateau (vue joueur ou ordi)
void printBoard(Board *board, bool playerView) {
    printf("Plateau :\n");
    for (int i = 0; i < board->size; i++) {
        for (int j = 0; j < board->size; j++) {
            if (playerView) {
                // Afficher les bateaux du joueur
                if (board->Matrice[i][j] == BOAT) {
                    printf("B ");
                } else {
                    printf(". ");
                }
            } else {
                // Montrer les résultats des tirs de l'ordinateur
                if (board->Matrice[i][j] == WATER_SHOT) {
                    printf("X "); // Tir réussi
                } else if (board->Matrice[i][j] == WRECK) {
                    printf("O "); // Bateau coulé
                } else {
                    printf(". "); // Eau non touchée
                }
            }
        }
        printf("\n");
    }
}
