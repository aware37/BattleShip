#include<stdlib.h>
#include<stdio.h>
#include <time.h>
#include <stdbool.h>

#include"fonction.h"


Board* createBoard(int size) {
    Board* board = malloc(sizeof(Board));
    if (board == NULL) {
        fprintf(stderr, "Erreur d'allocation de mémoire dans createBoard");
        exit(EXIT_FAILURE);
    }

    board->size = size;
    board->Matrice = malloc(size * sizeof(CaseType*));
    if (board->Matrice == NULL) {
        fprintf(stderr, "Erreur d'allocation de mémoire dans createBoard pour Matrice");
        free(board);
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < size; i++) {
        board->Matrice[i] = calloc(size, sizeof(CaseType));
        if (board->Matrice[i] == NULL) {
            fprintf(stderr, "Erreur d'allocation de mémoire dans createBoard pour Matrice[%d]", i);
            // Libérer la mémoire allouée précédemment
            for (int j = 0; j < i; j++) {
                free(board->Matrice[j]);
            }
            free(board->Matrice);
            free(board);
            exit(EXIT_FAILURE);
        }
    }

    return board;
}



Boat* createBoat(int size, int x, int y, char orientation) {
    // Validation de la taille du bateau
    if (size <= 0) {
        fprintf(stderr, "Erreur : La taille du bateau doit être supérieure à zéro.\n");
        exit(EXIT_FAILURE);
    }

    // Allocation de la mémoire pour le bateau
    Boat *boat = (Boat *)malloc(sizeof(Boat));
    if (boat == NULL) {
        fprintf(stderr, "Erreur : échec de l'allocation de mémoire pour le bateau.\n");
        exit(EXIT_FAILURE);
    }

    // Initialisation des propriétés du bateau
    boat->size = size;
    boat->x = x;
    boat->y = y;
    boat->orientation = orientation;

    return boat; // Retourner un pointeur vers le bateau
}

// Fonction pour vérifier si un bateau est en vie
bool isBoatAlive(Boat *boat, CaseType **board, int boardSize) {
    // Vérification des paramètres invalides
    if (boat == NULL || board == NULL || boardSize <= 0) {
        return false;
    }

    // Un bateau de taille non positive est considéré coulé
    if (boat->size <= 0) {
        return false;
    }

    if (boat->orientation == 0) {
        // Vérification pour un bateau horizontal
        for (int i = 0; i < boat->size; i++) {
            int x = boat->x + i;
            // Vérifie que les coordonnées x sont valides et que la case n'est pas en état WRECK
            if (x < 0 || x >= boardSize || board[boat->y][x] != WRECK) {
                // Si une case du bateau n'est pas en état WRECK, le bateau est en vie
                return true;
            }
        }
    } else if (boat->orientation == 1) {
        // Vérification pour un bateau vertical
        for (int i = 0; i < boat->size; i++) {
            int y = boat->y + i;
            // Vérifie que les coordonnées y sont valides et que la case n'est pas en état WRECK
            if (y < 0 || y >= boardSize || board[y][boat->x] != WRECK) {
                // Si une case du bateau n'est pas en état WRECK, le bateau est en vie
                return true;
            }
        }
    }

    // Si toutes les cases du bateau sont en état WRECK, le bateau est coulé
    return false;
}

void printBoard(Board *board, bool playerView) {
    printf("Plateau :\n");

    // Afficher les indices de colonne
    printf("  ");
    for (int i = 0; i < board->size; i++) {
        printf("%d ", i);
    }
    printf("\n");

    for (int i = 0; i < board->size; i++) {
        // Afficher les indices de ligne
        printf("%d ", i);

        for (int j = 0; j < board->size; j++) {
            if (playerView) {
                // Afficher les bateaux du joueur et les tirs reçus
                switch(board->Matrice[i][j]) {
                    case BOAT:
                        printf("B "); // Bateau non touché
                        break;
                    case WRECK:
                        printf("X "); // Bateau touché
                        break;
                    default:
                        printf(". "); // Eau ou tir dans l'eau
                        break;
                }
            } else {
                // Montrer les résultats des tirs de l'ordinateur
                switch(board->Matrice[i][j]) {
                    case WATER_SHOT:
                        printf("* "); // Tir dans l'eau
                        break;
                    case WRECK:
                        printf("X "); // Bateau touché
                        break;
                    default:
                        printf(". "); // Eau ou bateau non révélé
                        break;
                }
            }
        }
        printf("\n");
    }
}

void placeBoatsRandomly(Board *board) {
    int boatSizes[] = {5, 4, 3, 3, 2}; // Exemple de tailles de bateaux
    
    if (board->size <= 0) {
        fprintf(stderr, "Erreur : La taille du tableau n'est pas valide pour placer les bateaux.\n");
        return;
    }
    for (int i = 0; i < sizeof(boatSizes) / sizeof(boatSizes[0]); i++) {
        bool placed = false;
        while (!placed) {
            int x = rand() % board->size;
            int y = rand() % board->size;
            char orientation = rand() % 2 == 0 ? 0 : 1; // 0 pour horizontal, 1 pour vertical

            // Vérifier si le bateau peut être placé
            bool canPlace = true;
            for (int j = 0; j < boatSizes[i]; j++) {
                int checkX = orientation == 0 ? x + j : x;
                int checkY = orientation == 1 ? y + j : y;

                // Vérifier les limites et si la case est déjà occupée
                if (checkX >= board->size || checkY >= board->size || board->Matrice[checkY][checkX] != WATER) {
                    canPlace = false;
                    break;
                }
            }

            // Placer le bateau
            if (canPlace) {
                for (int j = 0; j < boatSizes[i]; j++) {
                    int placeX = orientation == 0 ? x + j : x;
                    int placeY = orientation == 1 ? y + j : y;

                    board->Matrice[placeY][placeX] = BOAT;
                }
                placed = true;
            }
        }
    }
}

void initializeGame(Game *game) {
    // Initialiser les plateaux avec de l'eau
    for (int i = 0; i < game->playerBoard->size; i++) {
        for (int j = 0; j < game->playerBoard->size; j++) {
            game->playerBoard->Matrice[i][j] = WATER;
            game->computerBoard->Matrice[i][j] = WATER;
        }
    }

    // Placer les bateaux de manière aléatoire
    placeBoatsRandomly(game->playerBoard);
    placeBoatsRandomly(game->computerBoard);
}




// Fonction pour séquencer un tour de jeu (joueur)
void playerTurn(Game *game) {
    int x, y;
    printf("C'est à votre tour de jouer !\n");
    printf("Entrez les coordonnées de votre tir (x y) : ");
    scanf("%d %d", &x, &y);

    // Vérifier les coordonnées valides et si la case n'a pas déjà été tirée
    if (x < 0 || x >= game->computerBoard->size || y < 0 || y >= game->computerBoard->size) {
        printf("Coordonnées invalides. Veuillez réessayer.\n");
        return; // Sortir de la fonction si les coordonnées sont invalides
    }

    if (game->computerBoard->Matrice[y][x] == WATER_SHOT || game->computerBoard->Matrice[y][x] == WRECK) {
        printf("Vous avez déjà tiré sur cette case. Veuillez réessayer.\n");
        return; // Sortir de la fonction si la case a déjà été tirée
    }

    // Effectuer le tir et mettre à jour le plateau en conséquence
    if (game->computerBoard->Matrice[y][x] == BOAT) {
        game->computerBoard->Matrice[y][x] = WRECK; // Marquer le bateau comme touché
        printf("C'est un coup réussi ! Vous avez touché un bateau.\n");
    } else {
        game->computerBoard->Matrice[y][x] = WATER_SHOT; // Marquer l'eau comme touchée
        printf("C'est un coup dans l'eau. Vous avez manqué.\n");
    }
}

void computerTurn(Game *game) {
    int x, y;
    bool validShot = false;

    printf("Tour de l'ordinateur...\n");

    // Continuer à choisir aléatoirement jusqu'à trouver une case non tirée
    while (!validShot) {
        x = rand() % game->playerBoard->size; // Choix aléatoire de x
        y = rand() % game->playerBoard->size; // Choix aléatoire de y

        // Vérifier si la case n'a pas déjà été tirée
        if (game->playerBoard->Matrice[y][x] == WATER || game->playerBoard->Matrice[y][x] == BOAT) {
            validShot = true;
        }
    }

    // Effectuer le tir
    if (game->playerBoard->Matrice[y][x] == BOAT) {
        game->playerBoard->Matrice[y][x] = WRECK; // Bateau touché
        printf("L'ordinateur a touché votre bateau en (%d, %d)!\n", x, y);
    } else {
        game->playerBoard->Matrice[y][x] = WATER_SHOT; // Coup dans l'eau
        printf("L'ordinateur a manqué en (%d, %d).\n", x, y);
    }
}





// Fonction pour vérifier si tous les bateaux du joueur ont coulé
bool allPlayerBoatsSunk(Game *game) {
    for (int i = 0; i < MAX_BOAT; i++) {
        if (isBoatAlive(&game->playerBoats[i], game->computerBoard->Matrice, game->computerBoard->size)) {
            return false; // Au moins un bateau est encore en vie
        }
    }
    return true; // Tous les bateaux du joueur ont coulé
}

// Fonction pour vérifier si tous les bateaux de l'ordinateur ont coulé
bool allComputerBoatsSunk(Game *game) {
    for (int i = 0; i < MAX_BOAT; i++) {
        if (isBoatAlive(&game->computerBoats[i], game->playerBoard->Matrice, game->playerBoard->size)) {
            return false; // Au moins un bateau est encore en vie
        }
    }
    return true; // Tous les bateaux de l'ordinateur ont coulé
}

void playGame() {
    Game game;

    // Initialisation des plateaux avec une taille spécifique
    game.playerBoard = createBoard(BOARD_SIZE);
    game.computerBoard = createBoard(BOARD_SIZE);

    // Allocation de mémoire pour les bateaux
    game.playerBoats = malloc(MAX_BOAT * sizeof(Boat));
    game.computerBoats = malloc(MAX_BOAT * sizeof(Boat));

    // Vérifiez si l'allocation de mémoire a réussi
    if (!game.playerBoard || !game.playerBoard->Matrice || 
        !game.computerBoard || !game.computerBoard->Matrice ||
        !game.playerBoats || !game.computerBoats) {
        fprintf(stderr, "Erreur d'allocation de mémoire.\n");
        // Libération des ressources allouées en cas d'erreur
        if (game.playerBoard) {
            for (int i = 0; i < BOARD_SIZE; i++) {
                free(game.playerBoard->Matrice[i]);
            }
            free(game.playerBoard->Matrice);
            free(game.playerBoard);
        }
        if (game.computerBoard) {
            for (int i = 0; i < BOARD_SIZE; i++) {
                free(game.computerBoard->Matrice[i]);
            }
            free(game.computerBoard->Matrice);
            free(game.computerBoard);
        }
        free(game.playerBoats);
        free(game.computerBoats);
        return;
    }

    // Initialisation du jeu
    initializeGame(&game);

    // Boucle de jeu jusqu'à ce qu'un joueur gagne
    bool game_over = false;
    while (!game_over) {
        printBoard(game.playerBoard, true);
        playerTurn(&game);

        // Vérifier si tous les bateaux de l'ordinateur ont coulé
        if (allComputerBoatsSunk(&game)) {
            printf("Joueur a gagné!\n");
            game_over = true;
            continue; // Passe à la prochaine itération pour éviter l'exécution de computerTurn
        }

        printBoard(game.computerBoard, false);
        computerTurn(&game);

        // Vérifier si tous les bateaux du joueur ont coulé
        if (allPlayerBoatsSunk(&game)) {
            printf("Ordinateur a gagné!\n");
            game_over = true;
        }
    }

    // Libération de la mémoire à la fin du jeu
    for (int i = 0; i < BOARD_SIZE; i++) {
        free(game.playerBoard->Matrice[i]);
        free(game.computerBoard->Matrice[i]);
    }
    free(game.playerBoard->Matrice);
    free(game.computerBoard->Matrice);
    free(game.playerBoard);
    free(game.computerBoard);
    free(game.playerBoats);
    free(game.computerBoats);
}






int main() {
    srand(time(NULL)); // Initialisation du générateur de nombres aléatoires

    playGame(); // Lancement du jeu

    return 0;
}